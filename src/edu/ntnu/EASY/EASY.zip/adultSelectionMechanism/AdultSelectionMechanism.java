interface AdultSelectionMechanism {
    
    public Population getAdults( Population population);
}
