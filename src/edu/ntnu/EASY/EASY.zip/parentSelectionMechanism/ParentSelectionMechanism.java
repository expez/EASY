interface AdultSelectionMechanism {

    public Population getParents( Population population);
}
