interface FitnessEvaluator {
    public void updateFitness();
}
