interface ReproductionMechanism {
    
    public Individual getOffspring( Individual mom, Individual dad);
}
